#!/usr/bin/env node
import { execSync, spawnSync } from "node:child_process";
import fs from "node:fs";

function safeRun(cmd) {
  try {
    return { ok: true, out: execSync(cmd, { encoding: "utf8", stdio: ["ignore","pipe","pipe"] }) };
  } catch (e) {
    return { ok: false, out: e.stdout?.toString() || "", err: e.stderr?.toString() || e.message };
  }
}

const scope = (process.argv[2] || "changed").toLowerCase();

// 1) 选取文件
let files = [];
if (scope === "all") {
  const res = safeRun("git ls-files");
  if (res.ok) files = res.out.split("\n").filter(Boolean);
} else {
  const res = safeRun("git status --porcelain");
  if (res.ok) {
    files = res.out.split("\n").filter(Boolean).map(l => l.slice(3)).filter(Boolean);
  }
}

const unique = Array.from(new Set(files));
const report = [];
let failures = 0;

function add(ok, title, detail="") {
  report.push({ ok, title, detail });
  if (!ok) failures += 1;
}

// 2) 基础检查：冲突标记与 TODO/FIXME
const scanTargets = unique.length ? unique : [];
function grep(pattern) {
  const res = safeRun(`git grep -n ${JSON.stringify(pattern)} -- ${scanTargets.join(" ")}`);
  return res.ok ? res.out.trim() : "";
}
const conflict = grep("<<<<<<<|>>>>>>>");
add(!conflict, "冲突标记检查 (<<<<<<< >>>>>>>)", conflict || "OK");

const todo = grep("TODO|FIXME");
add(true, "TODO/FIXME 检查", todo || "OK");

// 3) clang-format（若存在）
if (fs.existsSync(".clang-format")) {
  const cFiles = (scope === "all" ? safeRun("git ls-files '*.c' '*.cc' '*.cpp' '*.h' '*.hpp'").out.split("\n") : unique)
    .filter(f => /\.(c|cc|cpp|h|hpp)$/.test(f));
  if (cFiles.length) {
    const cmd = `clang-format --dry-run --Werror ${cFiles.map(f => JSON.stringify(f)).join(" ")}`;
    const res = safeRun(cmd);
    add(res.ok, "clang-format 规范检查", res.ok ? "OK" : (res.err || res.out || "格式不符合"));
  } else {
    add(true, "clang-format 规范检查", "无 C/C++ 文件");
  }
} else {
  add(true, "clang-format 规范检查", "未检测到 .clang-format，跳过");
}

// 4) DTS 语法检查（若变更含 .dts/.dtsi 且系统有 dtc）
const dtsFiles = unique.filter(f => /\.(dts|dtsi)$/.test(f));
if (dtsFiles.length) {
  const dtcTest = safeRun("bash -lc 'command -v dtc'");
  if (dtcTest.ok && dtcTest.out.trim()) {
    let okAll = true;
    let messages = [];
    for (const f of dtsFiles) {
      const res = safeRun(`dtc -I dts -O dtb -o /dev/null ${JSON.stringify(f)}`);
      if (!res.ok) { okAll = false; messages.push(`${f}: ${res.err || res.out}`); }
    }
    add(okAll, "DTS 编译检查 (dtc)", messages.join("\n") || "OK");
  } else {
    add(true, "DTS 编译检查 (dtc)", "未安装 dtc，跳过");
  }
} else {
  add(true, "DTS 编译检查 (dtc)", "无 DTS 变更");
}

// 5) Makefile 试跑（dry-run）
if (fs.existsSync("Makefile")) {
  const res = safeRun("make -n");
  add(res.ok, "Makefile 试跑 (-n)", res.ok ? "OK" : (res.err || res.out));
} else {
  add(true, "Makefile 试跑 (-n)", "未检测到 Makefile，跳过");
}

// 6) package.json 构建（可选）
if (fs.existsSync("package.json")) {
  const res = safeRun("bash -lc 'command -v npm && npm run -s build'");
  add(res.ok, "npm run build", res.ok ? "OK" : (res.err || res.out));
} else {
  add(true, "npm run build", "未检测到 package.json，跳过");
}

// 输出报告
console.log("\n==== ai-workflow post-check report ====");
for (const r of report) {
  console.log(`${r.ok ? "✅" : "❌"} ${r.title}`);
  if (r.detail && r.detail !== "OK") {
    console.log(r.detail.trim().slice(0, 4000));  // truncate
    console.log("");
  }
}
console.log(`Summary: ${report.filter(r=>r.ok).length} passed, ${report.filter(r=>!r.ok).length} failed.`);
process.exit(failures ? 1 : 0);
