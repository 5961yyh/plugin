#!/usr/bin/env node
import { execSync } from "node:child_process";
function run(cmd) { return execSync(cmd, { stdio: "inherit" }); }

const args = process.argv.slice(2);
if (!args.length) {
  console.error("Usage: /apply-and-check "goal" [paths...]");
  process.exit(2);
}

const joined = args.map(a => JSON.stringify(a)).join(" ");
run(`node commands/apply-with-plan.mjs ${joined}`);
try {
  run("node commands/post-check.mjs changed");
} catch (e) {
  process.exit(1);
}
