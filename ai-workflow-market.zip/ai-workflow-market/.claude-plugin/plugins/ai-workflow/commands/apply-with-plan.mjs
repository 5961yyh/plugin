#!/usr/bin/env node
import { execSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

function run(cmd, inherit=false) {
  return execSync(cmd, { encoding: "utf8", stdio: inherit ? "inherit" : ["ignore","pipe","pipe"] });
}

const args = process.argv.slice(2);
const goal = args[0] || "no-goal";
const paths = args.slice(1);

const now = new Date();
const tag = now.toISOString().replace(/[:.]/g, "-");
const planDir = path.join("docs","ai");
const planFile = path.join(planDir, `PLAN_${tag}.md`);
fs.mkdirSync(planDir, { recursive: true });

const defaultPlan = `# Plan

## Goal
${goal}

## Steps
- [ ] 明确要改的文件/模块
- [ ] 变更点清单
- [ ] 编译/测试项
- [ ] 回滚策略

## Notes
- 在提交信息里附上此 Plan 路径
`;

const planText = (process.env.CLAUDE_PLAN && process.env.CLAUDE_PLAN.trim()) || defaultPlan;
fs.writeFileSync(planFile, planText, "utf8");
console.log(`[ai-workflow] plan saved: ${planFile}`);
if (paths.length) console.log(`[ai-workflow] target paths: ${paths.join(", ")}`);

// show status before commit
let status = "";
try { status = run("git status --porcelain").trim(); } catch { status = ""; }

if (!status) {
  console.log("[ai-workflow] No changes to commit. (Plan saved)");
  process.exit(0);
}

// commit
run("git add -A", true);
const summary = status.split("\n").filter(Boolean).slice(0, 20).join("; ");
const msg = `chore(ai): apply changes

Plan: ${planFile}
Goal: ${goal}
Summary: ${summary}
`;
run(`git commit -m ${JSON.stringify(msg)}`, true);
console.log("✅ Git committed.");
