# ai-workflow 插件

Plan → Edit → Post-check → Git。把修改计划写入 `docs/ai/PLAN_*.md`，执行自检，然后自动提交。

## 安装

**方式 A：本地目录作为 Marketplace（开发/内网）**
```
/plugin marketplace add /absolute/path/to/ai-workflow-market
/plugin install ai-workflow
```

**方式 B：推到 GitHub 作为 Marketplace**
将本包根目录（含 `.claude-plugin/`）推到你的仓库根目录：
```
/plugin marketplace add <owner>/<repo>
/plugin install ai-workflow
```

## 命令

### 1) /apply-with-plan
```
/apply-with-plan "修复 rkisp 初始化失败" kernel-6.1/drivers/media/ device/rockchip/
```
- 生成 `docs/ai/PLAN_YYYYMMDD-HHMMSS.md`（若设置了 `CLAUDE_PLAN` 则使用其内容）
- *由你或 AI 完成改动*
- 若仓库有改动：自动 `git add -A && git commit -m ...`

> 也可结合：`CLAUDE_PLAN="$(cat /tmp/plan.md)" /apply-with-plan "目标说明"`

### 2) /post-check
```
/post-check           # 默认只检查“变更文件”
/post-check all       # 检查整个仓库
```
检查项（自动跳过缺失工具）：
- 冲突标记 `<<<<<<<`/`>>>>>>>`
- `TODO`/`FIXME` 残留
- 若有 `.clang-format`：`clang-format --dry-run --Werror`
- 若存在 DTS 变更：`dtc` 语法检查（如可用）
- 若有 `Makefile`：`make -n` 试跑（不执行）
- 若有 `package.json`：尝试 `npm run -s build`
- 输出汇总报告与非零退出码

### 3) /apply-and-check
```
/apply-and-check "修复 rkisp 初始化失败" kernel-6.1/drivers/media/
```
顺序：`apply-with-plan` → `post-check`。

## 备注
- 自检脚本尽可能“保守”：不存在的工具会跳过并提示。
- 你可按需扩展 `post-check.mjs`（例如接入 `shellcheck`, `cppcheck`, `pytest`, `ctest`）。
